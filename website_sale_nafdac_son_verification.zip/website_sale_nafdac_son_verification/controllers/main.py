# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import fields
from odoo.http import request, route

from odoo.addons.website_sale.controllers.cart import Cart
from odoo.addons.website_sale.controllers.main import WebsiteSale

# Minimum time between two self-service checks a single visitor can trigger
# on the same product, to avoid a "Check Authenticity" button being used to
# hammer the provider endpoint.
SELF_SERVICE_THROTTLE_SECONDS = 300


class WebsiteSaleRegulatoryVerification(WebsiteSale):

    def _prepare_checkout_page_values(self, order_sudo, **kwargs):
        # Runs on every checkout step (address, delivery...): keeps the
        # order-summary badges (rendered via website_sale.cart_lines, shared
        # across cart/checkout/payment) fresh for the customer.
        order_sudo._ensure_regulatory_verification_fresh()
        return super()._prepare_checkout_page_values(order_sudo, **kwargs)

    def _get_shop_payment_errors(self, order):
        order.sudo()._ensure_regulatory_verification_fresh()
        errors = super()._get_shop_payment_errors(order)
        errors += order.sudo()._get_regulatory_payment_errors()
        return errors

    @route('/shop/regulatory_check/<int:product_template_id>', type='jsonrpc',
           auth='public', website=True)
    def shop_regulatory_check(self, product_template_id, **kwargs):
        """Let a shopper trigger their own authenticity check on the product
        page. Throttled so the button can't be used to spam the underlying
        provider; outside the throttle window it always re-checks live."""
        template = request.env['product.template'].sudo().browse(product_template_id).exists()
        if not template or not template.requires_regulatory_verification:
            return {'error': 'not_applicable'}

        now = fields.Datetime.now()
        is_stale = (
            not template.last_verified_date
            or (now - template.last_verified_date).total_seconds() > SELF_SERVICE_THROTTLE_SECONDS
            or template.verification_status in ('not_checked', 'pending')
        )
        if is_stale:
            template._run_verification(is_manual=True)

        badge = template._get_regulatory_status_badge()
        return {
            'status': template.verification_status,
            'label': badge['label'],
            'css_class': badge['css_class'],
            'tooltip': badge['tooltip'],
        }


class CartRegulatoryVerification(Cart):

    @route(route='/shop/cart', type='http', auth='public', website=True, sitemap=False)
    def cart(self, id=None, access_token=None, revive_method='', **post):
        order_sudo = request.cart
        if order_sudo:
            order_sudo.sudo()._ensure_regulatory_verification_fresh()
        return super().cart(id=id, access_token=access_token, revive_method=revive_method, **post)
