# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import _, models


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    def _ensure_regulatory_verification_fresh(self):
        """Trigger a live NAFDAC/SON check for every regulated product in
        the order that is not currently in a 'verified' state (i.e. never
        checked, expired, pending or previously failed/errored).

        Called from the website checkout controllers so the badge shown to
        the customer - and the payment-blocking check - are never based on
        stale data. Runs sudo() since the caller is frequently a public
        (non-logged-in) visitor who has no write access to product.template.

        Note: at the cart/checkout stage, e-commerce order lines are not yet
        allocated to a specific lot/serial, so verification here happens at
        the product level. Lot-level verification still applies internally
        when the warehouse actually picks/validates the delivery (see
        nafdac_son_verification's stock.picking blocking hook).
        """
        for order in self:
            templates = order.order_line.product_id.product_tmpl_id.filtered(
                lambda t: t.requires_regulatory_verification)
            stale = templates.filtered(
                lambda t: t.verification_status in ('not_checked', 'pending', 'expired', 'error'))
            if stale:
                stale.sudo()._run_verification(is_manual=False)

    def _get_regulatory_payment_errors(self):
        """Return website_sale-style (title, message) error tuples if any
        regulated product in the order fails the company's blocking policy.
        """
        self.ensure_one()
        company = self.company_id or self.env.company
        block_failed = company.regulatory_block_on_failed
        block_unchecked = company.regulatory_block_on_unchecked
        if not (block_failed or block_unchecked):
            return []

        blocked_statuses = []
        if block_failed:
            blocked_statuses += ['failed', 'error']
        if block_unchecked:
            blocked_statuses += ['not_checked', 'pending', 'expired']

        blocking_lines = self.order_line.filtered(
            lambda l: l.product_id.product_tmpl_id.requires_regulatory_verification
            and l.product_id.product_tmpl_id.verification_status in blocked_statuses
        )
        if not blocking_lines:
            return []

        names = ', '.join(blocking_lines.mapped('product_id.display_name'))
        return [(
            _("Some products could not be verified"),
            _("The following products did not pass NAFDAC/SON authenticity "
              "verification and cannot be purchased online right now: "
              "%(names)s. Please remove them from your cart or contact us "
              "for assistance.", names=names),
        )]
