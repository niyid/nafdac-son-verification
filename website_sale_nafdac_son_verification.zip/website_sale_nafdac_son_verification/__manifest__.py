# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': "NAFDAC / SON Verification - Website Checkout",
    'summary': "Show and enforce NAFDAC/SON product verification during eCommerce checkout.",
    'description': """
NAFDAC / SON Verification - Website Checkout Integration
==========================================================

Bridges the ``nafdac_son_verification`` module into the eCommerce checkout
flow so end customers can see the authenticity check for themselves, not
just warehouse staff:

* A live (cache-aware) verification lookup is triggered automatically when
  a customer opens the cart page, the checkout/address step, and again at
  the payment step - so the badge shown is never more stale than the
  configured re-verification interval.
* Each regulated product in the cart/checkout order summary shows a
  badge: Verified / Failed / Pending / Not Yet Verified, with the provider's
  message available as a tooltip.
* A "Check Authenticity" button on the product page lets a shopper trigger
  a check themselves before adding to cart.
* If Settings > Inventory > Regulatory Verification is configured to block
  on failed/unchecked products, checkout payment is blocked with a clear,
  customer-facing explanation (reusing website_sale's existing payment
  error banner) until the issue is resolved.

This module auto-installs once both ``nafdac_son_verification`` and
``website_sale`` are installed.
""",
    'version': '19.0.1.0.0',
    'category': 'Supply Chain/Inventory',
    'author': 'Custom Development',
    'license': 'LGPL-3',

    'depends': [
        'nafdac_son_verification',
        'website_sale',
    ],

    'data': [
        'views/templates.xml',
    ],

    'auto_install': True,
    'installable': True,
    'application': False,
}
