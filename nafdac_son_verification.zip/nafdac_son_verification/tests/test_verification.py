# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo.exceptions import UserError
from odoo.tests import tagged
from odoo.tests.common import TransactionCase


@tagged('post_install', '-at_install')
class TestNafdacSonVerification(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.product = cls.env['product.template'].create({
            'name': 'Test Regulated Product',
            'type': 'consu',
            'is_storable': True,
            'tracking': 'lot',
            'requires_regulatory_verification': True,
            'regulatory_body': 'nafdac',
            'nafdac_reg_number': 'A4-1234',  # matches the demo provider's regex
        })
        cls.bad_product = cls.env['product.template'].create({
            'name': 'Test Regulated Product (Bad Number)',
            'type': 'consu',
            'is_storable': True,
            'requires_regulatory_verification': True,
            'regulatory_body': 'nafdac',
            'nafdac_reg_number': '!!not-a-valid-number!!',
        })

    def test_verify_now_passes_for_valid_number(self):
        self.product.action_verify_now()
        self.assertEqual(self.product.verification_status, 'verified')
        self.assertTrue(self.product.verification_log_ids)
        self.assertEqual(self.product.verification_log_ids[0].result_status, 'verified')

    def test_verify_now_fails_for_invalid_number(self):
        self.bad_product.action_verify_now()
        self.assertEqual(self.bad_product.verification_status, 'failed')

    def test_product_not_flagged_raises_on_verify(self):
        plain_product = self.env['product.template'].create({
            'name': 'Unregulated Product',
            'type': 'consu',
        })
        with self.assertRaises(UserError):
            plain_product.action_verify_now()

    def test_picking_blocked_on_failed_verification(self):
        self.bad_product.action_verify_now()
        self.env.company.regulatory_block_on_failed = True

        picking_type = self.env.ref('stock.picking_type_in')
        picking = self.env['stock.picking'].create({
            'picking_type_id': picking_type.id,
            'location_id': picking_type.default_location_src_id.id or self.env.ref('stock.stock_location_suppliers').id,
            'location_dest_id': picking_type.default_location_dest_id.id or self.env.ref('stock.stock_location_stock').id,
            'move_ids': [(0, 0, {
                'product_id': self.bad_product.product_variant_id.id,
                'product_uom_qty': 1,
                'product_uom': self.bad_product.uom_id.id,
                'location_id': picking_type.default_location_src_id.id or self.env.ref('stock.stock_location_suppliers').id,
                'location_dest_id': picking_type.default_location_dest_id.id or self.env.ref('stock.stock_location_stock').id,
            })],
        })
        picking.action_confirm()
        picking.move_ids.quantity = 1
        picking.move_ids.picked = True
        with self.assertRaises(UserError):
            picking.button_validate()

    def test_aggregate_status_worst_wins(self):
        mixin = self.env['product.template']
        self.assertEqual(mixin._aggregate_status(['verified', 'failed']), 'failed')
        self.assertEqual(mixin._aggregate_status(['verified', 'not_checked']), 'not_checked')
        self.assertEqual(mixin._aggregate_status(['verified', 'verified']), 'verified')
