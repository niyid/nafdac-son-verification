# Part of Odoo. See LICENSE file for full copyright and licensing details.
"""Tests for the form-configurable HTTP verification engine introduced in
services/base_provider.py (VerificationProvider._http_verify, resolve_path,
parse_extra_params) and its wiring through res.company /
res.config.settings / the verification mixin.

Network calls are mocked with unittest.mock so these run offline and
deterministically under `odoo-bin -i nafdac_son_verification --test-enable`
like any other Odoo test - no real HTTP server or open port is needed.
"""
import base64
import json
from unittest.mock import patch, MagicMock

import requests

from odoo.tests import tagged
from odoo.tests.common import TransactionCase

from ..services.base_provider import resolve_path, parse_extra_params
from ..services.nafdac_provider import DemoNafdacProvider
from ..services.son_provider import DemoSonProvider


def _mock_response(payload, status_code=200, raise_for_status_exc=None):
    """Build a MagicMock standing in for a requests.Response."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = payload
    if raise_for_status_exc is not None:
        resp.raise_for_status.side_effect = raise_for_status_exc
    else:
        resp.raise_for_status.return_value = None
    return resp


@tagged('post_install', '-at_install')
class TestResolvePathAndParseParams(TransactionCase):
    """Pure helper functions - no HTTP, no DB writes needed but TransactionCase
    keeps them consistent with the rest of the module's test suite."""

    def test_resolve_path_nested_dict(self):
        data = {'result': {'status': 'VALID'}}
        self.assertEqual(resolve_path(data, 'result.status'), 'VALID')

    def test_resolve_path_missing_key_returns_none(self):
        self.assertIsNone(resolve_path({'a': 1}, 'b.c'))

    def test_resolve_path_list_index(self):
        data = {'items': [{'ok': True}, {'ok': False}]}
        self.assertEqual(resolve_path(data, 'items.0.ok'), True)
        self.assertEqual(resolve_path(data, 'items.1.ok'), False)

    def test_resolve_path_out_of_range_index_returns_none(self):
        self.assertIsNone(resolve_path({'items': [1]}, 'items.5'))

    def test_resolve_path_blank_path_returns_none(self):
        self.assertIsNone(resolve_path({'a': 1}, ''))

    def test_parse_extra_params_ignores_blank_and_malformed_lines(self):
        text = "source=warehouse-app\napi_version=2\n\nmalformed_line\n"
        self.assertEqual(
            parse_extra_params(text),
            {'source': 'warehouse-app', 'api_version': '2'},
        )

    def test_parse_extra_params_empty_text(self):
        self.assertEqual(parse_extra_params(''), {})
        self.assertEqual(parse_extra_params(None), {})


@tagged('post_install', '-at_install')
class TestNafdacProviderDemoMode(TransactionCase):
    """Demo/structural-check behaviour must be unaffected by the new
    verify_mode plumbing - this is the default every existing install keeps
    using until someone opts in to Live HTTP API mode."""

    def test_demo_valid_format_is_verified(self):
        provider = DemoNafdacProvider(self.env, config={'verify_mode': 'demo'})
        result = provider.verify('A4-1234')
        self.assertEqual(result.result_status, 'verified')

    def test_demo_invalid_format_is_failed(self):
        provider = DemoNafdacProvider(self.env, config={'verify_mode': 'demo'})
        result = provider.verify('!! not a valid number !!')
        self.assertEqual(result.result_status, 'failed')

    def test_demo_empty_reference_is_error(self):
        provider = DemoNafdacProvider(self.env, config={'verify_mode': 'demo'})
        result = provider.verify('')
        self.assertEqual(result.result_status, 'error')

    def test_http_mode_without_endpoint_falls_back_to_demo(self):
        """A company with verify_mode='http' but no endpoint configured
        yet must not crash - it should degrade to the structural check."""
        provider = DemoNafdacProvider(self.env, config={'verify_mode': 'http', 'endpoint': None})
        result = provider.verify('A4-1234')
        self.assertEqual(result.result_status, 'verified')
        self.assertEqual(result.raw_response.get('mode'), 'demo')


@tagged('post_install', '-at_install')
class TestNafdacProviderLiveMode(TransactionCase):
    """Live HTTP API mode using the built-in NAFDAC default response mapping
    (is_genuine / message / nafdac_number)."""

    def _config(self, **overrides):
        base = {
            'verify_mode': 'http',
            'endpoint': 'https://example-provider.test/nafdac/verify',
            'api_key': 'secret-nafdac-token',
            'timeout': 5,
            'http_method': 'GET',
            'auth_type': 'bearer',
        }
        base.update(overrides)
        return base

    @patch('requests.get')
    def test_verified_result_and_default_field_mapping(self, mock_get):
        mock_get.return_value = _mock_response({
            'is_genuine': True,
            'message': 'Product is genuine',
            'nafdac_number': 'A4-9999',
        })
        provider = DemoNafdacProvider(self.env, config=self._config())
        result = provider.verify('A4-9999')

        self.assertEqual(result.result_status, 'verified')
        self.assertEqual(result.message, 'Product is genuine')
        self.assertEqual(result.external_reference, 'A4-9999')

        # Confirm the request was actually built the way Settings describes:
        # reference number under the configured param name, Bearer auth header.
        _, kwargs = mock_get.call_args
        self.assertEqual(kwargs['params']['reg_no'], 'A4-9999')
        self.assertEqual(kwargs['headers']['Authorization'], 'Bearer secret-nafdac-token')
        self.assertEqual(kwargs['timeout'], 5)

    @patch('requests.get')
    def test_failed_result(self, mock_get):
        mock_get.return_value = _mock_response({
            'is_genuine': False,
            'message': 'Not found in registry',
        })
        provider = DemoNafdacProvider(self.env, config=self._config())
        result = provider.verify('A4-0000')
        self.assertEqual(result.result_status, 'failed')
        self.assertEqual(result.message, 'Not found in registry')

    @patch('requests.get')
    def test_http_error_status_becomes_error_not_exception(self, mock_get):
        mock_get.return_value = _mock_response(
            {}, status_code=500,
            raise_for_status_exc=requests.exceptions.HTTPError('500 Server Error'))
        provider = DemoNafdacProvider(self.env, config=self._config())
        result = provider.verify('A4-9999')
        self.assertEqual(result.result_status, 'error')

    @patch('requests.get', side_effect=requests.exceptions.ConnectionError('refused'))
    def test_connection_failure_becomes_error_not_exception(self, mock_get):
        provider = DemoNafdacProvider(self.env, config=self._config())
        result = provider.verify('A4-9999')
        self.assertEqual(result.result_status, 'error')
        self.assertIn('refused', result.message)

    @patch('requests.get', side_effect=requests.exceptions.Timeout('timed out'))
    def test_timeout_becomes_error_not_exception(self, mock_get):
        provider = DemoNafdacProvider(self.env, config=self._config(timeout=1))
        result = provider.verify('A4-9999')
        self.assertEqual(result.result_status, 'error')


@tagged('post_install', '-at_install')
class TestSonProviderLiveModeCustomMapping(TransactionCase):
    """SON tested with a response shape that deliberately does NOT match the
    built-in defaults, to prove the mapping is genuinely form-driven and not
    hardcoded field names re-used under a different provider's name."""

    def test_nested_json_path_with_success_value_and_custom_header_auth(self):
        config = {
            'verify_mode': 'http',
            'endpoint': 'https://example-provider.test/son/verify',
            'api_key': 'secret-son-key',
            'timeout': 5,
            'http_method': 'GET',
            'auth_type': 'header',
            'auth_header_name': 'X-API-Key',
            'success_path': 'result.status',
            'success_value': 'VALID',
            'message_path': 'msg',
            'reference_path': 'ref',
        }
        provider = DemoSonProvider(self.env, config=config)

        with patch('requests.get') as mock_get:
            mock_get.return_value = _mock_response({
                'result': {'status': 'VALID'},
                'msg': 'Certificate valid',
                'ref': 'SON12345-X',
            })
            result = provider.verify('SON12345')
            self.assertEqual(result.result_status, 'verified')
            self.assertEqual(result.message, 'Certificate valid')
            self.assertEqual(result.external_reference, 'SON12345-X')
            _, kwargs = mock_get.call_args
            self.assertEqual(kwargs['headers']['X-API-Key'], 'secret-son-key')
            self.assertNotIn('Authorization', kwargs['headers'])

        with patch('requests.get') as mock_get:
            mock_get.return_value = _mock_response({
                'result': {'status': 'INVALID'},
                'msg': 'Unknown certificate',
            })
            result = provider.verify('SON00000')
            self.assertEqual(result.result_status, 'failed')
            self.assertEqual(result.message, 'Unknown certificate')

    @patch('requests.get')
    def test_basic_auth_sends_expected_credentials(self, mock_get):
        mock_get.return_value = _mock_response({
            'valid': True, 'message': 'ok', 'certificate_number': 'SON77777',
        })
        config = {
            'verify_mode': 'http',
            'endpoint': 'https://example-provider.test/son/verify-basic',
            'api_key': 'secret-son-key',
            'basic_username': 'clearinguser',
            'timeout': 5,
            'http_method': 'GET',
            'auth_type': 'basic',
        }
        provider = DemoSonProvider(self.env, config=config)
        result = provider.verify('SON77777')
        self.assertEqual(result.result_status, 'verified')

        _, kwargs = mock_get.call_args
        auth = kwargs['auth']
        self.assertEqual(auth.username, 'clearinguser')
        self.assertEqual(auth.password, 'secret-son-key')

    @patch('requests.post')
    def test_post_method_sends_reference_and_extra_params_as_json_body(self, mock_post):
        mock_post.return_value = _mock_response({
            'result': {'status': 'VALID'}, 'msg': 'ok', 'ref': 'SON12345',
        })
        config = {
            'verify_mode': 'http',
            'endpoint': 'https://example-provider.test/son/verify',
            'api_key': 'secret-son-key',
            'timeout': 5,
            'http_method': 'POST',
            'auth_type': 'header',
            'auth_header_name': 'X-API-Key',
            'success_path': 'result.status',
            'success_value': 'VALID',
            'extra_params': 'source=warehouse-app\napi_version=2',
        }
        provider = DemoSonProvider(self.env, config=config)
        result = provider.verify('SON12345')
        self.assertEqual(result.result_status, 'verified')

        _, kwargs = mock_post.call_args
        self.assertEqual(kwargs['json']['cert_no'], 'SON12345')
        self.assertEqual(kwargs['json']['source'], 'warehouse-app')
        self.assertEqual(kwargs['json']['api_version'], '2')


@tagged('post_install', '-at_install')
class TestRegulatoryVerificationSettingsIntegration(TransactionCase):
    """End-to-end through the real ORM: res.config.settings (what the
    Settings screen itself writes to) -> res.company -> the verification
    mixin's _get_provider_config -> the provider -> a stored log entry.
    Confirms switching modes is purely data-driven, no code path needed."""

    def test_settings_save_flows_through_to_company_and_provider_config(self):
        settings = self.env['res.config.settings'].create({
            'son_verify_mode': 'http',
            'son_api_endpoint': 'https://example-provider.test/son/verify',
            'son_api_key': 'secret-son-key',
            'son_auth_type': 'header',
            'son_auth_header_name': 'X-API-Key',
            'son_success_path': 'result.status',
            'son_success_value': 'VALID',
            'son_message_path': 'msg',
            'son_reference_path': 'ref',
        })
        settings.execute()

        company = self.env.company
        self.assertEqual(company.son_verify_mode, 'http')
        self.assertEqual(company.son_api_endpoint, 'https://example-provider.test/son/verify')
        self.assertEqual(company.son_success_path, 'result.status')

        product = self.env['product.template'].create({
            'name': 'Test SON Product',
            'requires_regulatory_verification': True,
            'regulatory_body': 'son',
            'son_mancap_number': 'SON12345',
        })

        with patch('requests.get') as mock_get:
            mock_get.return_value = _mock_response({
                'result': {'status': 'VALID'}, 'msg': 'Certificate valid', 'ref': 'SON12345-X',
            })
            product.action_verify_now()

        self.assertEqual(product.verification_status, 'verified')
        self.assertEqual(len(product.verification_log_ids), 1)
        log = product.verification_log_ids[0]
        self.assertEqual(log.message, 'Certificate valid')
        self.assertEqual(log.external_reference, 'SON12345-X')

    def test_switching_back_to_demo_mode_stops_calling_requests(self):
        self.env.company.write({
            'nafdac_verify_mode': 'demo',
            'nafdac_api_endpoint': 'https://example-provider.test/nafdac/verify',
            'nafdac_api_key': 'irrelevant-in-demo-mode',
        })
        product = self.env['product.template'].create({
            'name': 'Test NAFDAC Product (Demo Mode)',
            'requires_regulatory_verification': True,
            'regulatory_body': 'nafdac',
            'nafdac_reg_number': 'A4-1234',
        })
        with patch('requests.get') as mock_get:
            product.action_verify_now()
            mock_get.assert_not_called()
        self.assertEqual(product.verification_status, 'verified')
