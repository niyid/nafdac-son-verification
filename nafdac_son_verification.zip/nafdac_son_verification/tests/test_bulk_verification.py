# Part of Odoo. See LICENSE file for full copyright and licensing details.
"""End-to-end test coverage at realistic data volume: multiple vendors,
~25 regulated products across both NAFDAC and SON, several Purchase Orders
each received into inventory as separate lots, and a single bulk run of the
verification wizard across every lot at once - mirroring
demo/bulk_e2e_workflow.py so the same scenario that gets screenshotted/
recorded is also asserted on in CI.
"""
from odoo.tests import tagged
from odoo.tests.common import TransactionCase

NAFDAC_PRODUCTS = [
    ("Paracetamol 500mg Tablets (100-pack)", "A4-1234", True),
    ("Amoxicillin 250mg Capsules (50-pack)", "A4-5678", True),
    ("Vitamin C 1000mg Effervescent", "A7-0912", True),
    ("Chloroquine Phosphate 250mg", "A4-3321", True),
    ("Multivitamin Syrup 200ml", "B3-8890", True),
    ("Metformin 500mg Tablets", "A4-4471", True),
    ("Ibuprofen 400mg Tablets", "A2-1190", True),
    ("ORS Sachets (Oral Rehydration Salts)", "A9-2231", True),
    ("Ciprofloxacin 500mg Tablets", "A4-9012", True),
    ("Ferrous Sulphate + Folic Acid Tablets", "A6-4410", True),
    ("Counterfeit-Risk Cough Syrup 100ml", "NOT-A-REAL-NUMBER", False),
    ("Unregistered Herbal Mixture 250ml", "???", False),
    ("Suspicious Skin Cream 50g", "12345", False),
]

# NOTE: the module's SON_NUMBER_RE is `^[A-Za-z0-9]{4,20}$` - no hyphens.
# Hyphenated "SON-MC-xxxxx" style numbers therefore fail structural
# validation as-is; this is asserted on explicitly below rather than
# silently worked around, since it's a real constraint worth knowing about
# before wiring up a live provider expecting hyphenated certificate numbers.
SON_PRODUCTS_NO_HYPHENS = [
    ("Extension Cable 5-Socket 13A", "SONMC10234", True),
    ("Rechargeable Emergency Lantern", "SONMC88214", True),
    ("Ceramic Cooking Gas Regulator", "SONMC55019", True),
    ("Electric Pressing Iron 1200W", "SONMC77302", True),
    ("USB-C Fast Charger 25W", "SONMC44510", True),
]
SON_PRODUCTS_HYPHENATED = [
    ("Solar Rechargeable Fan", "SON-MC-91120"),
    ("Bottled Table Water 75cl", "SON-MC-22981"),
]
SON_PRODUCTS_INVALID = [
    ("Substandard Power Strip", "FAKE-CERT"),
    ("Uncertified Circuit Breaker", "000000000000000000000"),  # too long
]


@tagged('post_install', '-at_install')
class TestBulkVerificationWorkflow(TransactionCase):

    def _make_regulated_product(self, name, body, reg_no):
        vals = {
            'name': name,
            'type': 'consu',
            'is_storable': True,
            'tracking': 'lot',
            'requires_regulatory_verification': True,
            'regulatory_body': body,
        }
        vals['nafdac_reg_number' if body == 'nafdac' else 'son_mancap_number'] = reg_no
        return self.env['product.template'].create(vals)

    def _receive_into_inventory(self, vendor, products_and_qty):
        """Confirm a PO for the given products and validate its receipt,
        assigning one lot per line. Returns (picking, lots)."""
        po = self.env['purchase.order'].create({
            'partner_id': vendor.id,
            'order_line': [(0, 0, {
                'product_id': p.product_variant_id.id,
                'product_qty': qty,
                'product_uom_id': p.uom_id.id,
                'price_unit': 100.0,
            }) for p, qty in products_and_qty],
        })
        po.button_confirm()
        picking = po.picking_ids[0]
        lots = self.env['stock.lot']
        for line, (product, qty) in zip(picking.move_ids, products_and_qty):
            lot = self.env['stock.lot'].create({
                'name': f"LOT-{product.id}-BULK-TEST",
                'product_id': product.product_variant_id.id,
            })
            line.move_line_ids[:1].write({'lot_id': lot.id, 'quantity': qty})
            lots |= lot
        picking.move_ids.picked = True
        picking.button_validate()
        return picking, lots

    def test_bulk_receipt_and_verification_across_25_lots(self):
        self.env.company.write({'nafdac_verify_mode': 'demo', 'son_verify_mode': 'demo'})
        vendor = self.env['res.partner'].create({'name': 'Bulk Test Vendor', 'is_company': True})

        all_products = []
        expected_verified = 0
        expected_failed = 0
        for name, reg_no, expected in NAFDAC_PRODUCTS:
            p = self._make_regulated_product(name, 'nafdac', reg_no)
            all_products.append((p, 10))
            expected_verified += 1 if expected else 0
            expected_failed += 0 if expected else 1
        for name, reg_no, expected in SON_PRODUCTS_NO_HYPHENS:
            p = self._make_regulated_product(name, 'son', reg_no)
            all_products.append((p, 10))
            expected_verified += 1 if expected else 0
            expected_failed += 0 if expected else 1
        for name, reg_no in SON_PRODUCTS_HYPHENATED:
            p = self._make_regulated_product(name, 'son', reg_no)
            all_products.append((p, 10))
            expected_failed += 1  # hyphens are rejected by SON_NUMBER_RE
        for name, reg_no in SON_PRODUCTS_INVALID:
            p = self._make_regulated_product(name, 'son', reg_no)
            all_products.append((p, 10))
            expected_failed += 1

        self.assertEqual(len(all_products), 22)

        # Split into batches of 5 across 5 separate Purchase Orders/receipts,
        # matching how a warehouse would actually receive several shipments.
        pickings = self.env['stock.picking']
        all_lots = self.env['stock.lot']
        batches = [all_products[i:i + 5] for i in range(0, len(all_products), 5)]
        for batch in batches:
            picking, lots = self._receive_into_inventory(vendor, batch)
            self.assertEqual(picking.state, 'done')
            pickings |= picking
            all_lots |= lots

        self.assertEqual(len(pickings), len(batches))
        self.assertEqual(len(all_lots), len(all_products))
        for lot in all_lots:
            self.assertEqual(lot.verification_status, 'not_checked')

        # One bulk verification run across every lot from every receipt at once.
        wizard = self.env['nafdac.son.verification.wizard'].create({
            'res_model': 'stock.lot',
            'res_ids': ','.join(str(i) for i in all_lots.ids),
        })
        wizard.action_run_verification()
        all_lots.invalidate_recordset()

        verified = all_lots.filtered(lambda l: l.verification_status == 'verified')
        failed = all_lots.filtered(lambda l: l.verification_status == 'failed')

        self.assertEqual(len(verified), expected_verified,
                          f"Expected {expected_verified} verified, got {len(verified)}: "
                          f"{verified.mapped('name')}")
        self.assertEqual(len(failed), expected_failed,
                          f"Expected {expected_failed} failed, got {len(failed)}: "
                          f"{failed.mapped('name')}")
        self.assertEqual(len(verified) + len(failed), len(all_lots))

        # Every lot got exactly one log entry from this single bulk run.
        for lot in all_lots:
            self.assertEqual(len(lot.verification_log_ids), 1)

        # Hyphenated SON numbers specifically must have failed structural
        # validation - this is the real, previously-undocumented constraint
        # bulk testing surfaced.
        hyphenated_lots = all_lots.filtered(
            lambda l: l.product_id.son_mancap_number in ('SON-MC-91120', 'SON-MC-22981'))
        self.assertEqual(len(hyphenated_lots), 2)
        self.assertTrue(all(l.verification_status == 'failed' for l in hyphenated_lots))

    def test_bulk_verification_wizard_result_summary_counts_match(self):
        self.env.company.write({'nafdac_verify_mode': 'demo'})
        vendor = self.env['res.partner'].create({'name': 'Summary Test Vendor', 'is_company': True})
        products = [
            self._make_regulated_product(f"Valid Product {i}", 'nafdac', f"A4-{1000 + i}")
            for i in range(8)
        ] + [
            self._make_regulated_product(f"Invalid Product {i}", 'nafdac', "BAD")
            for i in range(4)
        ]
        _picking, lots = self._receive_into_inventory(vendor, [(p, 5) for p in products])

        wizard = self.env['nafdac.son.verification.wizard'].create({
            'res_model': 'stock.lot',
            'res_ids': ','.join(str(i) for i in lots.ids),
        })
        wizard.action_run_verification()
        self.assertIn("12 record(s)", wizard.result_summary)
        self.assertIn("8 passed", wizard.result_summary)
        self.assertIn("4 failed", wizard.result_summary)

    def test_verification_status_survives_reread_after_bulk_run(self):
        """Regression guard: verification_status must reflect the latest log
        entry even after multiple lots are checked in the same wizard call,
        not just the last one processed (an ordering bug would only show up
        at this scale, not with a single record)."""
        self.env.company.write({'nafdac_verify_mode': 'demo'})
        vendor = self.env['res.partner'].create({'name': 'Ordering Test Vendor', 'is_company': True})
        products = [
            self._make_regulated_product(f"Product {i}", 'nafdac', f"A4-{2000 + i}" if i % 2 == 0 else "X")
            for i in range(10)
        ]
        _picking, lots = self._receive_into_inventory(vendor, [(p, 3) for p in products])

        wizard = self.env['nafdac.son.verification.wizard'].create({
            'res_model': 'stock.lot',
            'res_ids': ','.join(str(i) for i in lots.ids),
        })
        wizard.action_run_verification()
        lots.invalidate_recordset()

        for i, lot in enumerate(lots.sorted('id')):
            expected = 'verified' if i % 2 == 0 else 'failed'
            self.assertEqual(lot.verification_status, expected,
                              f"Lot {lot.name} (index {i}) has wrong status after bulk run")
