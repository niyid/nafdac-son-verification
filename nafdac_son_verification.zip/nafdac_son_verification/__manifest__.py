# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': "NAFDAC / SON Product Verification",
    'summary': "Verify product originality against NAFDAC and SON regulatory databases directly from Inventory.",
    'description': """
NAFDAC / SON Product Authenticity Verification
================================================

Extends the Inventory app so that regulated products (drugs, food, cosmetics,
medical devices, electrical/electronic goods, etc.) can be checked for
originality against:

  * NAFDAC  - National Agency for Food and Drug Administration and Control
  * SON     - Standards Organisation of Nigeria (MANCAP / SONCAP / SOM marks)

Key features
------------
* Registration/certification numbers stored on both the Product and the
  Lot/Serial, since regulatory numbers are frequently batch-specific.
* A pluggable, form-configurable "verification provider" architecture
  (services/) - Settings > Inventory > Regulatory Verification lets you
  switch each body from Demo/Structural Check to a Live HTTP API and
  configure the endpoint, HTTP method, auth scheme and JSON response field
  mapping entirely from the UI, no code changes needed for a typical REST
  provider. Drop to a custom provider class only for non-REST integrations.
* Every lookup is logged (request, response, status, user, timestamp) in a
  dedicated Verification Log model for full traceability/audit.
* Receipts and deliveries can be *blocked* (configurable) when a product or
  lot has failed verification, or is still unchecked, straight from the
  Inventory validation flow (button_validate).
* Bulk "Verify Now" wizard usable from Products, Lots/Serials and Stock Move
  Lines.
* Scheduled action to auto re-verify records whose last check has expired
  (cache/TTL configurable in Settings).
* Status badges/decorations on Product, Lot and Stock Move Line list & form
  views (Verified / Failed / Expired / Pending / Not Checked).
* Printable Verification Certificate report for a Lot/Serial.
""",
    'version': '19.0.1.1.0',
    'category': 'Supply Chain/Inventory',
    'author': 'Custom Development',
    'license': 'LGPL-3',
    'website': 'https://www.example.com',

    'depends': [
        'stock',
        'product',
        'product_expiry',
        'mail',
    ],

    'external_dependencies': {
        'python': ['requests'],
    },

    'data': [
        'security/regulatory_security.xml',
        'security/ir.model.access.csv',

        'data/ir_cron_data.xml',
        'data/mail_template_data.xml',

        'views/product_template_views.xml',
        'views/stock_lot_views.xml',
        'views/stock_move_line_views.xml',
        'views/stock_picking_views.xml',
        'views/verification_log_views.xml',
        'views/res_config_settings_views.xml',
        'views/menu_views.xml',

        'wizard/regulatory_verification_wizard_views.xml',

        'report/verification_certificate_report.xml',
        'report/verification_certificate_templates.xml',
    ],

    'demo': [
        'data/demo_data.xml',
    ],

    'installable': True,
    'application': False,
    'auto_install': False,
}
