# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import _, api, fields, models
from odoo.exceptions import UserError


class NafdacSonVerificationWizard(models.TransientModel):
    _name = 'nafdac.son.verification.wizard'
    _description = 'Bulk NAFDAC/SON Verification'

    res_model = fields.Selection(
        [('product.template', 'Products'), ('stock.lot', 'Lots/Serials')],
        string='Apply To', required=True)
    res_ids = fields.Char(string='Record IDs', required=True, help="Technical: comma separated ids.")
    record_count = fields.Integer(string='Records', compute='_compute_record_count')
    result_summary = fields.Text(string='Result', readonly=True)

    @api.depends('res_ids')
    def _compute_record_count(self):
        for wizard in self:
            wizard.record_count = len(wizard._get_ids())

    def _get_ids(self):
        self.ensure_one()
        return [int(i) for i in (self.res_ids or '').split(',') if i]

    def action_run_verification(self):
        self.ensure_one()
        ids = self._get_ids()
        if not ids:
            raise UserError(_("No records selected."))

        records = self.env[self.res_model].browse(ids)
        eligible = records.filtered(lambda r: r._get_verification_targets())
        if not eligible:
            raise UserError(_(
                "None of the selected records require NAFDAC/SON verification "
                "(check the 'Requires Verification' flag on the product)."))

        logs = eligible._run_verification(is_manual=True)
        verified = logs.filtered(lambda l: l.result_status == 'verified')
        failed = logs.filtered(lambda l: l.result_status in ('failed', 'error'))

        self.result_summary = _(
            "Checked %(count)s record(s): %(verified)s passed, %(failed)s failed/errored.",
            count=len(eligible), verified=len(verified), failed=len(failed),
        )
        return {
            'type': 'ir.actions.act_window',
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
        }
