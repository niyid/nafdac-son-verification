# Part of Odoo. See LICENSE file for full copyright and licensing details.
import logging
import re

from .base_provider import VerificationProvider, VerificationResult

_logger = logging.getLogger(__name__)

# NAFDAC registration numbers commonly look like "A4-1234" (Food),
# "04-1234" (Drugs), or the newer "NAFDAC/XX-1234" formats. We keep the
# pattern permissive on purpose - real validation should happen server-side.
NAFDAC_NUMBER_RE = re.compile(r'^[A-Za-z0-9]{1,4}[\-/][A-Za-z0-9]{2,10}$')


class DemoNafdacProvider(VerificationProvider):
    """Reference/demo implementation.

    This does NOT call the real NAFDAC service (no stable public API is
    published at the time of writing). It performs a structural sanity
    check on the registration number and returns a deterministic mock
    result so the rest of the module (logging, blocking on validate,
    scheduled re-checks, UI badges...) can be built, tested and demoed end
    to end. Replace the body of ``verify()`` with a real HTTP call once you
    have an integration agreement with NAFDAC or a licensed data provider.
    """

    code = 'nafdac'
    display_name = "NAFDAC"

    def verify(self, reference_number, product_name=None, extra_context=None):
        try:
            if not reference_number:
                return VerificationResult(
                    result_status='error',
                    message="No NAFDAC registration number provided.",
                )

            endpoint = self.config.get('endpoint')
            api_key = self.config.get('api_key')

            if endpoint and api_key:
                # ------------------------------------------------------------------
                # Real integration point.
                # Uncomment/adapt once NAFDAC (or a licensed reseller) has issued
                # you an endpoint + API key. Keep the try/except so a network
                # failure degrades to 'error' instead of crashing the transaction.
                #
                # import requests
                # resp = requests.get(
                #     endpoint,
                #     params={'reg_no': reference_number},
                #     headers={'Authorization': f'Bearer {api_key}'},
                #     timeout=self.config.get('timeout', 15),
                # )
                # resp.raise_for_status()
                # data = resp.json()
                # status = 'verified' if data.get('is_genuine') else 'failed'
                # return VerificationResult(
                #     result_status=status,
                #     message=data.get('message', ''),
                #     raw_response=data,
                #     external_reference=data.get('nafdac_number'),
                # )
                _logger.info("NAFDAC live endpoint configured but not implemented; "
                             "falling back to structural check for %s", reference_number)

            if NAFDAC_NUMBER_RE.match(reference_number.strip()):
                return VerificationResult(
                    result_status='verified',
                    message="Registration number matches expected NAFDAC format. "
                            "(Demo provider - structural check only, not a live "
                            "database lookup.)",
                    raw_response={'reference_number': reference_number, 'mode': 'demo'},
                    external_reference=reference_number,
                )
            return VerificationResult(
                result_status='failed',
                message="Registration number does not match a recognised NAFDAC "
                        "format (e.g. 'A4-1234'). Please double check the number "
                        "printed on the pack.",
                raw_response={'reference_number': reference_number, 'mode': 'demo'},
            )
        except Exception as exc:  # noqa: BLE001 - provider must never raise
            _logger.exception("NAFDAC verification failed")
            return VerificationResult(result_status='error', message=str(exc))
