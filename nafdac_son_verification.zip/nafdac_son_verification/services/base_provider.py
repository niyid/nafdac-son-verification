# Part of Odoo. See LICENSE file for full copyright and licensing details.
"""
Pluggable verification-provider architecture.
==============================================

Neither NAFDAC nor SON currently publish a stable, publicly documented REST
API for real-time product/certificate lookups. Both agencies *do* run
verification portals (NAFDAC Greenbook / mobile-authentication codes, and the
SON MANCAP/SONCAP certificate portal) that are typically integrated via:

    * a bilateral/commercial data-sharing agreement (most common), or
    * screen-scraping the public verification portal (fragile, not
      recommended for production), or
    * a value-added reseller / clearing-house API that already has an
      agreement with the agency.

Rather than hard-coding a guess at an endpoint, this module defines a small
Strategy-pattern interface (``VerificationProvider``) with one required
method: ``verify()``. Swap ``DemoNafdacProvider`` / ``DemoSonProvider`` for a
real implementation the moment you have credentials/endpoints - nothing else
in the module needs to change because everything talks to providers through
``provider_registry.get_provider()``.

To plug in the real service:
    1. Duplicate ``nafdac_provider.py`` / ``son_provider.py``.
    2. Implement ``verify()`` to call the real endpoint (use ``requests``,
       respect timeouts, and never let network errors raise past this layer
       - catch them and return a ``result_status='error'`` payload instead).
    3. Register your class in ``provider_registry.PROVIDERS``.
    4. Point the "Regulatory Body" selection at your new provider key, and/or
       set the endpoint & API key in Settings > Inventory > Regulatory
       Verification.
"""

from datetime import datetime


class VerificationResult:
    """Simple value object returned by every provider.verify() call."""

    def __init__(self, result_status, message='', raw_response=None,
                 external_reference=None, checked_at=None):
        # result_status: one of 'verified', 'failed', 'pending', 'error'
        self.result_status = result_status
        self.message = message
        self.raw_response = raw_response or {}
        self.external_reference = external_reference
        self.checked_at = checked_at or datetime.now()

    def as_log_values(self):
        return {
            'result_status': self.result_status,
            'message': self.message,
            'raw_response': str(self.raw_response),
        }


class VerificationProvider:
    """Abstract base class - subclass this for each regulatory body."""

    #: short technical key, must match the selection value used on
    #: product.template.regulatory_body / stock.lot.regulatory_body
    code = None
    #: human readable name shown in logs/errors
    display_name = "Unnamed Provider"

    def __init__(self, env, config=None):
        self.env = env
        # `config` is a dict typically sourced from res.company fields:
        # {'endpoint': ..., 'api_key': ..., 'timeout': ...}
        self.config = config or {}

    def verify(self, reference_number, product_name=None, extra_context=None):
        """Look up ``reference_number`` against the regulatory database.

        Must return a :class:`VerificationResult`. Implementations must
        never raise - network/parsing errors should be caught and returned
        as ``VerificationResult(result_status='error', message=str(exc))``
        so the caller (log model) always has something consistent to store.
        """
        raise NotImplementedError
