# Part of Odoo. See LICENSE file for full copyright and licensing details.
"""
Pluggable verification-provider architecture.
==============================================

Neither NAFDAC nor SON currently publish a stable, publicly documented REST
API for real-time product/certificate lookups. Both agencies *do* run
verification portals (NAFDAC Greenbook / mobile-authentication codes, and the
SON MANCAP/SONCAP certificate portal) that are typically integrated via:

    * a bilateral/commercial data-sharing agreement (most common), or
    * screen-scraping the public verification portal (fragile, not
      recommended for production), or
    * a value-added reseller / clearing-house API that already has an
      agreement with the agency.

Rather than hard-coding a guess at an endpoint, this module defines a small
Strategy-pattern interface (``VerificationProvider``) with one required
method: ``verify()``. Every concrete provider (``DemoNafdacProvider`` /
``DemoSonProvider``) is *form-configurable*: an administrator switches it
from "Demo / Structural Check" to "Live HTTP API" in Settings > Inventory >
Regulatory Verification and fills in the endpoint, HTTP method, auth scheme
and response field mapping there - no Python changes required for the
common case of a JSON REST endpoint. ``VerificationProvider._http_verify()``
below is the generic engine every concrete provider delegates to once
"Live HTTP API" mode is selected.

If a real integration doesn't fit the generic GET/POST + JSON-path shape
(e.g. SOAP, screen-scraping, signed requests), drop down to code:
    1. Duplicate ``nafdac_provider.py`` / ``son_provider.py``.
    2. Override ``verify()`` directly instead of calling ``_http_verify()``.
    3. Register your class in ``provider_registry.PROVIDERS``.
"""

from datetime import datetime


def resolve_path(data, path):
    """Traverse a dotted path (e.g. ``'result.is_genuine'`` or
    ``'items.0.status'``) through a nested dict/list structure decoded from
    a JSON response. Returns ``None`` if any segment is missing instead of
    raising, since response shapes vary per provider and a missing field
    should degrade gracefully rather than crash the request.
    """
    if not path:
        return None
    current = data
    for part in path.split('.'):
        part = part.strip()
        if isinstance(current, dict):
            current = current.get(part)
        elif isinstance(current, list):
            try:
                current = current[int(part)]
            except (ValueError, IndexError):
                return None
        else:
            return None
    return current


def parse_extra_params(text):
    """Parse the "Extra Request Parameters" settings field: one ``key=value``
    pair per line, blank lines and lines without ``=`` ignored."""
    params = {}
    for line in (text or '').splitlines():
        line = line.strip()
        if not line or '=' not in line:
            continue
        key, value = line.split('=', 1)
        key = key.strip()
        if key:
            params[key] = value.strip()
    return params


class VerificationResult:
    """Simple value object returned by every provider.verify() call."""

    def __init__(self, result_status, message='', raw_response=None,
                 external_reference=None, checked_at=None):
        # result_status: one of 'verified', 'failed', 'pending', 'error'
        self.result_status = result_status
        self.message = message
        self.raw_response = raw_response or {}
        self.external_reference = external_reference
        self.checked_at = checked_at or datetime.now()

    def as_log_values(self):
        return {
            'result_status': self.result_status,
            'message': self.message,
            'raw_response': str(self.raw_response),
        }


class VerificationProvider:
    """Abstract base class - subclass this for each regulatory body."""

    #: short technical key, must match the selection value used on
    #: product.template.regulatory_body / stock.lot.regulatory_body
    code = None
    #: human readable name shown in logs/errors
    display_name = "Unnamed Provider"

    def __init__(self, env, config=None):
        self.env = env
        # `config` is sourced from res.company (see Settings > Inventory >
        # Regulatory Verification) via verification_mixin._get_provider_config().
        # Expected keys (all optional except where a live call is wanted):
        #   verify_mode          'demo' | 'http'
        #   endpoint             full URL of the verification API
        #   api_key              credential/token, stored on a groups='base.group_system' field
        #   timeout              request timeout in seconds
        #   http_method          'GET' | 'POST'
        #   param_name           query/body key the reference number is sent under
        #   extra_params         raw 'key=value' per-line text, sent with every request
        #   auth_type            'none' | 'bearer' | 'header' | 'basic'
        #   auth_header_name     header name used when auth_type == 'header'
        #   basic_username       username used when auth_type == 'basic'
        #   success_path         dotted JSON path to the pass/fail indicator
        #   success_value        exact string the success_path value must equal;
        #                        blank means "truthy" (Python bool(...) check)
        #   message_path         dotted JSON path to a human-readable message
        #   reference_path       dotted JSON path to the provider's own record id
        self.config = config or {}

    def verify(self, reference_number, product_name=None, extra_context=None):
        """Look up ``reference_number`` against the regulatory database.

        Must return a :class:`VerificationResult`. Implementations must
        never raise - network/parsing errors should be caught and returned
        as ``VerificationResult(result_status='error', message=str(exc))``
        so the caller (log model) always has something consistent to store.
        """
        raise NotImplementedError

    def _http_verify(self, reference_number, default_param_name,
                      default_success_path, default_message_path,
                      default_reference_path):
        """Generic, form-configurable JSON REST lookup. Every behavioural
        knob is read from ``self.config`` (i.e. from the Settings form) with
        sensible per-body defaults as a fallback, so switching a body to
        "Live HTTP API" mode works out of the box against an endpoint that
        follows the shape implied by the defaults, and can be re-pointed at
        a differently-shaped API purely through configuration.
        """
        import requests
        from requests.auth import HTTPBasicAuth

        endpoint = self.config.get('endpoint')
        method = (self.config.get('http_method') or 'GET').upper()
        param_name = self.config.get('param_name') or default_param_name
        timeout = self.config.get('timeout') or 15

        params = parse_extra_params(self.config.get('extra_params'))
        params[param_name] = reference_number

        headers = {}
        auth = None
        auth_type = self.config.get('auth_type') or 'bearer'
        api_key = self.config.get('api_key')
        if auth_type == 'bearer' and api_key:
            headers['Authorization'] = 'Bearer %s' % api_key
        elif auth_type == 'header' and api_key:
            headers[self.config.get('auth_header_name') or 'Authorization'] = api_key
        elif auth_type == 'basic' and api_key:
            auth = HTTPBasicAuth(self.config.get('basic_username') or '', api_key)

        try:
            if method == 'POST':
                response = requests.post(
                    endpoint, json=params, headers=headers, auth=auth, timeout=timeout)
            else:
                response = requests.get(
                    endpoint, params=params, headers=headers, auth=auth, timeout=timeout)
            response.raise_for_status()
            data = response.json()
        except Exception as exc:  # noqa: BLE001 - provider must never raise
            return VerificationResult(
                result_status='error',
                message="%s request to %s failed: %s" % (self.display_name, endpoint, exc),
            )

        success_path = self.config.get('success_path') or default_success_path
        success_value = self.config.get('success_value')
        message_path = self.config.get('message_path') or default_message_path
        reference_path = self.config.get('reference_path') or default_reference_path

        raw_success = resolve_path(data, success_path)
        if success_value:
            is_success = str(raw_success) == success_value
        else:
            is_success = bool(raw_success)

        message = resolve_path(data, message_path)
        return VerificationResult(
            result_status='verified' if is_success else 'failed',
            message=message if isinstance(message, str) else (message or ''),
            raw_response=data,
            external_reference=resolve_path(data, reference_path),
        )
