# Part of Odoo. See LICENSE file for full copyright and licensing details.
from .nafdac_provider import DemoNafdacProvider
from .son_provider import DemoSonProvider

# Map of regulatory_body selection key -> Provider class.
# Add your own real-world implementation here once available, e.g.:
#   PROVIDERS['nafdac'] = LiveNafdacProvider
PROVIDERS = {
    'nafdac': DemoNafdacProvider,
    'son': DemoSonProvider,
}


def get_provider(code, env, config=None):
    """Instantiate the provider registered for ``code``.

    :param code: 'nafdac' or 'son'
    :param env: odoo Environment (passed through in case a provider needs
                to read other models, e.g. ir.config_parameter)
    :param config: dict with provider-specific settings (endpoint, api_key,
                    timeout) usually sourced from res.company.
    """
    provider_class = PROVIDERS.get(code)
    if not provider_class:
        raise ValueError(f"No verification provider registered for '{code}'")
    return provider_class(env, config=config)
