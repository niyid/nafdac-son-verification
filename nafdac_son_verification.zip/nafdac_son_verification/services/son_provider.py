# Part of Odoo. See LICENSE file for full copyright and licensing details.
import logging
import re

from .base_provider import VerificationProvider, VerificationResult

_logger = logging.getLogger(__name__)

# MANCAP / SONCAP certificate numbers are alphanumeric, agency-issued.
# Kept permissive - swap for the real validation/lookup once you have API
# access (SON's SONCAP portal or a licensed clearing agent's API).
SON_NUMBER_RE = re.compile(r'^[A-Za-z0-9]{4,20}$')


class DemoSonProvider(VerificationProvider):
    """Reference/demo implementation for SON (MANCAP/SONCAP/SOM marks).

    Same caveat as the NAFDAC demo provider: this performs a structural
    sanity check only. Replace ``verify()`` with a real call once SON (or a
    licensed reseller/clearing agent) issues you API access.
    """

    code = 'son'
    display_name = "SON"

    def verify(self, reference_number, product_name=None, extra_context=None):
        try:
            if not reference_number:
                return VerificationResult(
                    result_status='error',
                    message="No SON certification number provided.",
                )

            verify_mode = self.config.get('verify_mode') or 'demo'
            endpoint = self.config.get('endpoint')

            if verify_mode == 'http' and endpoint:
                # Live mode: entirely driven by Settings > Inventory >
                # Regulatory Verification - endpoint, HTTP method, auth
                # scheme and response field mapping are all form fields on
                # res.company. Defaults below match a typical
                # {"valid": true, "message": "...", "certificate_number": "..."}
                # response shape; override the mapping fields in Settings if
                # your provider's response looks different.
                return self._http_verify(
                    reference_number,
                    default_param_name='cert_no',
                    default_success_path='valid',
                    default_message_path='message',
                    default_reference_path='certificate_number',
                )
            if verify_mode == 'http' and not endpoint:
                _logger.info("SON set to Live HTTP API mode but no endpoint is "
                             "configured; falling back to structural check for %s",
                             reference_number)

            if SON_NUMBER_RE.match(reference_number.strip()):
                return VerificationResult(
                    result_status='verified',
                    message="Certificate number matches expected SON format. "
                            "(Demo provider - structural check only, not a live "
                            "database lookup.)",
                    raw_response={'reference_number': reference_number, 'mode': 'demo'},
                    external_reference=reference_number,
                )
            return VerificationResult(
                result_status='failed',
                message="Certificate number does not match a recognised SON "
                        "MANCAP/SONCAP format.",
                raw_response={'reference_number': reference_number, 'mode': 'demo'},
            )
        except Exception as exc:  # noqa: BLE001 - provider must never raise
            _logger.exception("SON verification failed")
            return VerificationResult(result_status='error', message=str(exc))
