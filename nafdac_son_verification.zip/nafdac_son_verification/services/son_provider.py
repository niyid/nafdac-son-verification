# Part of Odoo. See LICENSE file for full copyright and licensing details.
import logging
import re

from .base_provider import VerificationProvider, VerificationResult

_logger = logging.getLogger(__name__)

# MANCAP / SONCAP certificate numbers are alphanumeric, agency-issued.
# Kept permissive - swap for the real validation/lookup once you have API
# access (SON's SONCAP portal or a licensed clearing agent's API).
SON_NUMBER_RE = re.compile(r'^[A-Za-z0-9]{4,20}$')


class DemoSonProvider(VerificationProvider):
    """Reference/demo implementation for SON (MANCAP/SONCAP/SOM marks).

    Same caveat as the NAFDAC demo provider: this performs a structural
    sanity check only. Replace ``verify()`` with a real call once SON (or a
    licensed reseller/clearing agent) issues you API access.
    """

    code = 'son'
    display_name = "SON"

    def verify(self, reference_number, product_name=None, extra_context=None):
        try:
            if not reference_number:
                return VerificationResult(
                    result_status='error',
                    message="No SON certification number provided.",
                )

            endpoint = self.config.get('endpoint')
            api_key = self.config.get('api_key')

            if endpoint and api_key:
                # ------------------------------------------------------------------
                # Real integration point - mirror the pattern used in
                # nafdac_provider.py once SON credentials/endpoint are available.
                #
                # import requests
                # resp = requests.get(
                #     endpoint,
                #     params={'cert_no': reference_number},
                #     headers={'Authorization': f'Bearer {api_key}'},
                #     timeout=self.config.get('timeout', 15),
                # )
                # resp.raise_for_status()
                # data = resp.json()
                # status = 'verified' if data.get('valid') else 'failed'
                # return VerificationResult(
                #     result_status=status,
                #     message=data.get('message', ''),
                #     raw_response=data,
                #     external_reference=data.get('certificate_number'),
                # )
                _logger.info("SON live endpoint configured but not implemented; "
                             "falling back to structural check for %s", reference_number)

            if SON_NUMBER_RE.match(reference_number.strip()):
                return VerificationResult(
                    result_status='verified',
                    message="Certificate number matches expected SON format. "
                            "(Demo provider - structural check only, not a live "
                            "database lookup.)",
                    raw_response={'reference_number': reference_number, 'mode': 'demo'},
                    external_reference=reference_number,
                )
            return VerificationResult(
                result_status='failed',
                message="Certificate number does not match a recognised SON "
                        "MANCAP/SONCAP format.",
                raw_response={'reference_number': reference_number, 'mode': 'demo'},
            )
        except Exception as exc:  # noqa: BLE001 - provider must never raise
            _logger.exception("SON verification failed")
            return VerificationResult(result_status='error', message=str(exc))
