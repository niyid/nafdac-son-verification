# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import fields, models

VERIFY_MODE_SELECTION = [
    ('demo', 'Demo / Structural Check'),
    ('http', 'Live HTTP API'),
]
HTTP_METHOD_SELECTION = [
    ('GET', 'GET'),
    ('POST', 'POST'),
]
AUTH_TYPE_SELECTION = [
    ('none', 'None'),
    ('bearer', 'Bearer Token'),
    ('header', 'Custom Header'),
    ('basic', 'Basic Auth'),
]


class ResCompany(models.Model):
    _inherit = 'res.company'

    # --- NAFDAC provider config ---------------------------------------------
    nafdac_verify_mode = fields.Selection(
        VERIFY_MODE_SELECTION, string='NAFDAC Verification Mode', default='demo',
        help="Demo mode only performs a structural sanity-check on the "
             "registration number - no network call is made. Switch to Live "
             "HTTP API once you have an endpoint (from NAFDAC or a licensed "
             "data provider/reseller) and fill in the fields below.")
    nafdac_api_endpoint = fields.Char(string='NAFDAC API Endpoint')
    nafdac_api_key = fields.Char(string='NAFDAC API Key', groups='base.group_system')
    nafdac_timeout = fields.Integer(string='NAFDAC Timeout (s)', default=15)
    nafdac_http_method = fields.Selection(
        HTTP_METHOD_SELECTION, string='NAFDAC HTTP Method', default='GET')
    nafdac_param_name = fields.Char(
        string='NAFDAC Reference Param Name', default='reg_no',
        help="Query/body parameter name the registration number is sent under.")
    nafdac_extra_params = fields.Text(
        string='NAFDAC Extra Request Parameters',
        help="Additional static parameters sent with every request, one "
             "'key=value' pair per line.")
    nafdac_auth_type = fields.Selection(
        AUTH_TYPE_SELECTION, string='NAFDAC Auth Type', default='bearer')
    nafdac_auth_header_name = fields.Char(
        string='NAFDAC Auth Header Name', default='Authorization',
        help="Used only when Auth Type = Custom Header.")
    nafdac_basic_username = fields.Char(
        string='NAFDAC Basic Auth Username',
        help="Used only when Auth Type = Basic Auth (the API Key above is "
             "used as the password).")
    nafdac_success_path = fields.Char(
        string='NAFDAC Success Field (JSON path)', default='is_genuine',
        help="Dotted path into the JSON response indicating pass/fail, "
             "e.g. 'is_genuine' or 'data.status'.")
    nafdac_success_value = fields.Char(
        string='NAFDAC Success Value',
        help="Leave blank to treat the Success Field as truthy. Set this if "
             "the API returns a specific string instead, e.g. 'GENUINE'.")
    nafdac_message_path = fields.Char(
        string='NAFDAC Message Field (JSON path)', default='message')
    nafdac_reference_path = fields.Char(
        string='NAFDAC External Reference Field (JSON path)', default='nafdac_number')

    # --- SON provider config -------------------------------------------------
    son_verify_mode = fields.Selection(
        VERIFY_MODE_SELECTION, string='SON Verification Mode', default='demo',
        help="Demo mode only performs a structural sanity-check on the "
             "certificate number - no network call is made. Switch to Live "
             "HTTP API once you have an endpoint (from SON or a licensed "
             "clearing agent/reseller) and fill in the fields below.")
    son_api_endpoint = fields.Char(string='SON API Endpoint')
    son_api_key = fields.Char(string='SON API Key', groups='base.group_system')
    son_timeout = fields.Integer(string='SON Timeout (s)', default=15)
    son_http_method = fields.Selection(
        HTTP_METHOD_SELECTION, string='SON HTTP Method', default='GET')
    son_param_name = fields.Char(
        string='SON Reference Param Name', default='cert_no',
        help="Query/body parameter name the certificate number is sent under.")
    son_extra_params = fields.Text(
        string='SON Extra Request Parameters',
        help="Additional static parameters sent with every request, one "
             "'key=value' pair per line.")
    son_auth_type = fields.Selection(
        AUTH_TYPE_SELECTION, string='SON Auth Type', default='bearer')
    son_auth_header_name = fields.Char(
        string='SON Auth Header Name', default='Authorization',
        help="Used only when Auth Type = Custom Header.")
    son_basic_username = fields.Char(
        string='SON Basic Auth Username',
        help="Used only when Auth Type = Basic Auth (the API Key above is "
             "used as the password).")
    son_success_path = fields.Char(
        string='SON Success Field (JSON path)', default='valid',
        help="Dotted path into the JSON response indicating pass/fail, "
             "e.g. 'valid' or 'data.status'.")
    son_success_value = fields.Char(
        string='SON Success Value',
        help="Leave blank to treat the Success Field as truthy. Set this if "
             "the API returns a specific string instead, e.g. 'VALID'.")
    son_message_path = fields.Char(
        string='SON Message Field (JSON path)', default='message')
    son_reference_path = fields.Char(
        string='SON External Reference Field (JSON path)', default='certificate_number')

    # --- Policy ----------------------------------------------------------------
    regulatory_block_on_failed = fields.Boolean(
        string='Block Transfers on Failed Verification', default=True,
        help="If enabled, validating a receipt/delivery containing a product or "
             "lot whose verification status is 'Failed' will be blocked.")
    regulatory_block_on_unchecked = fields.Boolean(
        string='Block Transfers on Unchecked Products', default=False,
        help="If enabled, validating a transfer containing a regulated product "
             "that has never been checked (or whose check has expired) will be "
             "blocked until it is verified.")
    regulatory_cache_days = fields.Integer(
        string='Re-verification Interval (days)', default=180,
        help="Number of days a 'Verified' result remains valid before the "
             "scheduled action marks it 'Expired' and queues it for re-check.")
