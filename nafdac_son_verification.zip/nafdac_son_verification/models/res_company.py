# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import fields, models


class ResCompany(models.Model):
    _inherit = 'res.company'

    # --- NAFDAC provider config -------------------------------------------------
    nafdac_api_endpoint = fields.Char(string='NAFDAC API Endpoint')
    nafdac_api_key = fields.Char(string='NAFDAC API Key', groups='base.group_system')
    nafdac_timeout = fields.Integer(string='NAFDAC Timeout (s)', default=15)

    # --- SON provider config -----------------------------------------------------
    son_api_endpoint = fields.Char(string='SON API Endpoint')
    son_api_key = fields.Char(string='SON API Key', groups='base.group_system')
    son_timeout = fields.Integer(string='SON Timeout (s)', default=15)

    # --- Policy ------------------------------------------------------------------
    regulatory_block_on_failed = fields.Boolean(
        string='Block Transfers on Failed Verification', default=True,
        help="If enabled, validating a receipt/delivery containing a product or "
             "lot whose verification status is 'Failed' will be blocked.")
    regulatory_block_on_unchecked = fields.Boolean(
        string='Block Transfers on Unchecked Products', default=False,
        help="If enabled, validating a transfer containing a regulated product "
             "that has never been checked (or whose check has expired) will be "
             "blocked until it is verified.")
    regulatory_cache_days = fields.Integer(
        string='Re-verification Interval (days)', default=180,
        help="Number of days a 'Verified' result remains valid before the "
             "scheduled action marks it 'Expired' and queues it for re-check.")
