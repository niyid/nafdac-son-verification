# Part of Odoo. See LICENSE file for full copyright and licensing details.
from datetime import timedelta

from odoo import _, api, fields, models
from odoo.exceptions import UserError

from .verification_log import REGULATORY_BODY_SELECTION, VERIFICATION_STATUS_SELECTION
from ..services.provider_registry import get_provider


class NafdacSonVerificationMixin(models.AbstractModel):
    """Shared fields + logic for anything that can be verified: products and
    lots/serials. Concrete models must implement ``_get_verification_targets``
    which returns a list of dicts describing what to check, e.g.::

        [{'regulatory_body': 'nafdac', 'reference_number': 'A4-1234'}, ...]

    and must define the actual stored fields (regulatory_body,
    nafdac_reg_number, son_mancap_number, verification_status,
    last_verified_date) themselves, since a Many2one to res.company /
    concrete storage differs between product.template and stock.lot.
    """
    _name = 'nafdac.son.verification.mixin'
    _description = 'NAFDAC/SON Verification Mixin'

    def _get_verification_targets(self):
        """Return list of (regulatory_body, reference_number) tuples to check
        for a single record in ``self``."""
        raise NotImplementedError

    def _get_verification_log_values(self, regulatory_body, reference_number):
        """Extra values (product_id / lot_id / ...) to store on the log,
        implemented by the concrete model."""
        raise NotImplementedError

    def _get_company_for_provider_config(self):
        return self.env.company

    def _run_verification(self, is_manual=True):
        """Call the appropriate provider for every applicable regulatory body
        on every record in ``self``, log the result, and write the aggregated
        status back onto the record. Returns the recordset of created logs.
        """
        Log = self.env['nafdac.son.verification.log']
        created_logs = Log

        for record in self:
            targets = record._get_verification_targets()
            if not targets:
                continue

            statuses = []
            for regulatory_body, reference_number in targets:
                if not reference_number:
                    statuses.append('not_checked')
                    continue

                company = record._get_company_for_provider_config()
                config = record._get_provider_config(regulatory_body, company)
                provider = get_provider(regulatory_body, record.env, config=config)
                result = provider.verify(reference_number, product_name=record.display_name)

                log_vals = {
                    'regulatory_body': regulatory_body,
                    'reference_number': reference_number,
                    'result_status': result.result_status,
                    'message': result.message,
                    'raw_response': str(result.raw_response),
                    'external_reference': result.external_reference,
                    'is_manual': is_manual,
                    'company_id': company.id,
                }
                log_vals.update(record._get_verification_log_values(regulatory_body, reference_number))
                log = Log.create(log_vals)
                created_logs |= log
                statuses.append(result.result_status)

                if result.result_status in ('failed', 'error'):
                    record._notify_regulatory_failure(log, is_manual)

            record.write({
                'verification_status': record._aggregate_status(statuses),
                'last_verified_date': fields.Datetime.now(),
            })
        return created_logs

    @api.model
    def _aggregate_status(self, statuses):
        """Worst-status-wins aggregation across multiple regulatory bodies
        checked on the same record (e.g. a product requiring both NAFDAC and
        SON clearance)."""
        priority = ['error', 'failed', 'expired', 'pending', 'not_checked', 'verified']
        for status in priority:
            if status in statuses:
                return status
        return 'not_checked'

    def _get_provider_config(self, regulatory_body, company):
        if regulatory_body == 'nafdac':
            return {
                'verify_mode': company.nafdac_verify_mode,
                'endpoint': company.nafdac_api_endpoint,
                'api_key': company.nafdac_api_key,
                'timeout': company.nafdac_timeout,
                'http_method': company.nafdac_http_method,
                'param_name': company.nafdac_param_name,
                'extra_params': company.nafdac_extra_params,
                'auth_type': company.nafdac_auth_type,
                'auth_header_name': company.nafdac_auth_header_name,
                'basic_username': company.nafdac_basic_username,
                'success_path': company.nafdac_success_path,
                'success_value': company.nafdac_success_value,
                'message_path': company.nafdac_message_path,
                'reference_path': company.nafdac_reference_path,
            }
        elif regulatory_body == 'son':
            return {
                'verify_mode': company.son_verify_mode,
                'endpoint': company.son_api_endpoint,
                'api_key': company.son_api_key,
                'timeout': company.son_timeout,
                'http_method': company.son_http_method,
                'param_name': company.son_param_name,
                'extra_params': company.son_extra_params,
                'auth_type': company.son_auth_type,
                'auth_header_name': company.son_auth_header_name,
                'basic_username': company.son_basic_username,
                'success_path': company.son_success_path,
                'success_value': company.son_success_value,
                'message_path': company.son_message_path,
                'reference_path': company.son_reference_path,
            }
        return {}

    def _notify_regulatory_failure(self, log, is_manual):
        """Post a chatter message on the record (always) and email the
        Inventory managers (only for automatic/cron-triggered failures - a
        manual check already shows its result to the user immediately)."""
        self.ensure_one()
        if hasattr(self, 'message_post'):
            self.message_post(body=_(
                "NAFDAC/SON verification failed for %(ref)s: %(msg)s",
                ref=log.reference_number, msg=log.message or log.result_status,
            ))
        if not is_manual:
            template = self.env.ref(
                'nafdac_son_verification.mail_template_regulatory_verification_failed',
                raise_if_not_found=False)
            if template:
                managers = self.env.ref('stock.group_stock_manager').users
                emails = ', '.join(managers.mapped('email')) if managers else False
                if emails:
                    template.send_mail(
                        log.id, force_send=False,
                        email_values={'email_to': emails},
                    )

    def action_verify_now(self):
        """UI button action: verify selected records synchronously and show
        a notification summarising the outcome."""
        if not self:
            return
        logs = self._run_verification(is_manual=True)
        failed = logs.filtered(lambda l: l.result_status in ('failed', 'error'))
        verified = logs.filtered(lambda l: l.result_status == 'verified')

        message = _("%(verified)s check(s) passed, %(failed)s failed/errored out of %(total)s.",
                     verified=len(verified), failed=len(failed), total=len(logs))
        notif_type = 'danger' if failed else 'success'
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _("Regulatory Verification"),
                'message': message,
                'type': notif_type,
                'sticky': False,
            },
        }

    @api.model
    def _cron_reverify_expired(self, model_name):
        """Generic helper called by the scheduled action for each concrete
        model (product.template, stock.lot). Marks stale 'verified' records
        as 'expired' then re-runs verification on anything not currently
        'verified'."""
        Model = self.env[model_name]
        cache_days = self.env.company.regulatory_cache_days or 180
        stale_cutoff = fields.Datetime.now() - timedelta(days=cache_days)

        stale = Model.search([
            ('verification_status', '=', 'verified'),
            ('last_verified_date', '<=', stale_cutoff),
        ])
        if stale:
            stale.write({'verification_status': 'expired'})

        to_recheck = Model.search([
            ('verification_status', 'in', ['expired', 'pending', 'error']),
        ])
        if to_recheck:
            to_recheck._run_verification(is_manual=False)
