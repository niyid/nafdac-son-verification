# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import fields, models


class StockMoveLine(models.Model):
    _inherit = 'stock.move.line'

    requires_regulatory_verification = fields.Boolean(
        related='product_id.requires_regulatory_verification', string='Regulated')
    regulatory_verification_status = fields.Selection(
        related='lot_id.verification_status', string='Verification Status',
        help="Verification status of the Lot/Serial. If this move line has "
             "no lot, the product-level status is used instead when the "
             "transfer is validated.")

    def _get_effective_verification_status(self):
        """Status to consider for blocking purposes: lot status takes
        precedence, falling back to the product template's status when the
        product isn't tracked by lot/serial."""
        self.ensure_one()
        if self.lot_id:
            return self.lot_id.verification_status
        return self.product_id.product_tmpl_id.verification_status
