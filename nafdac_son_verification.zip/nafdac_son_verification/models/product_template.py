# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import _, api, fields, models
from odoo.exceptions import UserError

from .verification_log import REGULATORY_BODY_SELECTION, VERIFICATION_STATUS_SELECTION


class ProductTemplate(models.Model):
    _name = 'product.template'
    _inherit = ['product.template', 'nafdac.son.verification.mixin']

    requires_regulatory_verification = fields.Boolean(
        string='Requires NAFDAC/SON Verification',
        compute='_compute_requires_regulatory_verification', store=True, readonly=False,
        help="When enabled, this product's registration/certification numbers "
             "will be checked against the regulatory body selected below, and "
             "Inventory transfers can be blocked if verification fails or is "
             "missing (see Settings > Inventory).")
    regulatory_body = fields.Selection(
        REGULATORY_BODY_SELECTION, string='Regulatory Body', default='none',
        compute='_compute_requires_regulatory_verification', store=True, readonly=False)

    nafdac_reg_number = fields.Char(
        string='NAFDAC Registration No.',
        help="Registration number as printed on the pack, e.g. 'A4-1234'. "
             "For batch-specific numbers, set it on the Lot/Serial instead - "
             "the lot value takes precedence when both are present.")
    son_mancap_number = fields.Char(
        string='SON MANCAP/SONCAP No.',
        help="Certification number issued by the Standards Organisation of "
             "Nigeria. For batch-specific numbers, set it on the Lot/Serial "
             "instead - the lot value takes precedence when both are present.")

    verification_status = fields.Selection(
        VERIFICATION_STATUS_SELECTION, string='Verification Status',
        default='not_checked', copy=False, tracking=True)
    last_verified_date = fields.Datetime(string='Last Checked On', copy=False)
    verification_log_ids = fields.One2many(
        'nafdac.son.verification.log', 'product_tmpl_id', string='Verification Logs')
    verification_log_count = fields.Integer(compute='_compute_verification_log_count')

    @api.depends('categ_id.requires_regulatory_verification', 'categ_id.default_regulatory_body')
    def _compute_requires_regulatory_verification(self):
        for product in self:
            if product._origin.id:
                # Don't clobber a manual choice on an existing record just
                # because the category changed; only pre-fill on creation.
                continue
            product.requires_regulatory_verification = product.categ_id.requires_regulatory_verification
            product.regulatory_body = product.categ_id.default_regulatory_body or 'none'

    def _compute_verification_log_count(self):
        for product in self:
            product.verification_log_count = len(product.verification_log_ids)

    # --- Mixin implementation ----------------------------------------------------
    def _get_verification_targets(self):
        self.ensure_one()
        if not self.requires_regulatory_verification or self.regulatory_body == 'none':
            return []
        bodies = ['nafdac', 'son'] if self.regulatory_body == 'both' else [self.regulatory_body]
        targets = []
        for body in bodies:
            reference_number = (self.nafdac_reg_number if body == 'nafdac'
                                 else self.son_mancap_number)
            targets.append((body, reference_number))
        return targets

    def _get_verification_log_values(self, regulatory_body, reference_number):
        self.ensure_one()
        # product.template has no direct stock, use the first variant so the
        # log stays queryable from product.product too.
        product_variant = self.product_variant_ids[:1]
        return {'product_id': product_variant.id if product_variant else False}

    def action_verify_now(self):
        for product in self:
            if not product.requires_regulatory_verification:
                raise UserError(_(
                    "%(name)s is not flagged as requiring regulatory verification.",
                    name=product.display_name))
        return super().action_verify_now()

    def action_view_verification_logs(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Verification Logs'),
            'res_model': 'nafdac.son.verification.log',
            'view_mode': 'list,form',
            'domain': [('product_tmpl_id', '=', self.id)],
        }

    def _get_regulatory_status_badge(self):
        """Small dict describing how to render this product's verification
        status to an end user (backend kanban badge or website template).
        Kept on the model so every UI surface stays visually consistent."""
        self.ensure_one()
        mapping = {
            'verified': {'css_class': 'text-bg-success', 'label': _('NAFDAC/SON Verified'),
                         'icon': 'fa-check-circle'},
            'failed': {'css_class': 'text-bg-danger', 'label': _('Verification Failed'),
                       'icon': 'fa-times-circle'},
            'error': {'css_class': 'text-bg-danger', 'label': _('Verification Error'),
                      'icon': 'fa-exclamation-circle'},
            'expired': {'css_class': 'text-bg-warning', 'label': _('Verification Expired'),
                        'icon': 'fa-clock-o'},
            'pending': {'css_class': 'text-bg-secondary', 'label': _('Verification Pending'),
                        'icon': 'fa-hourglass-half'},
            'not_checked': {'css_class': 'text-bg-secondary', 'label': _('Not Yet Verified'),
                             'icon': 'fa-question-circle'},
        }
        badge = dict(mapping.get(self.verification_status, mapping['not_checked']))
        latest_log = self.sudo().verification_log_ids[:1]
        badge['tooltip'] = latest_log.message if latest_log else ''
        return badge


