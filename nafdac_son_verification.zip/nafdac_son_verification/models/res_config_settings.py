# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    nafdac_verify_mode = fields.Selection(related='company_id.nafdac_verify_mode', readonly=False)
    nafdac_api_endpoint = fields.Char(related='company_id.nafdac_api_endpoint', readonly=False)
    nafdac_api_key = fields.Char(related='company_id.nafdac_api_key', readonly=False)
    nafdac_timeout = fields.Integer(related='company_id.nafdac_timeout', readonly=False)
    nafdac_http_method = fields.Selection(related='company_id.nafdac_http_method', readonly=False)
    nafdac_param_name = fields.Char(related='company_id.nafdac_param_name', readonly=False)
    nafdac_extra_params = fields.Text(related='company_id.nafdac_extra_params', readonly=False)
    nafdac_auth_type = fields.Selection(related='company_id.nafdac_auth_type', readonly=False)
    nafdac_auth_header_name = fields.Char(related='company_id.nafdac_auth_header_name', readonly=False)
    nafdac_basic_username = fields.Char(related='company_id.nafdac_basic_username', readonly=False)
    nafdac_success_path = fields.Char(related='company_id.nafdac_success_path', readonly=False)
    nafdac_success_value = fields.Char(related='company_id.nafdac_success_value', readonly=False)
    nafdac_message_path = fields.Char(related='company_id.nafdac_message_path', readonly=False)
    nafdac_reference_path = fields.Char(related='company_id.nafdac_reference_path', readonly=False)

    son_verify_mode = fields.Selection(related='company_id.son_verify_mode', readonly=False)
    son_api_endpoint = fields.Char(related='company_id.son_api_endpoint', readonly=False)
    son_api_key = fields.Char(related='company_id.son_api_key', readonly=False)
    son_timeout = fields.Integer(related='company_id.son_timeout', readonly=False)
    son_http_method = fields.Selection(related='company_id.son_http_method', readonly=False)
    son_param_name = fields.Char(related='company_id.son_param_name', readonly=False)
    son_extra_params = fields.Text(related='company_id.son_extra_params', readonly=False)
    son_auth_type = fields.Selection(related='company_id.son_auth_type', readonly=False)
    son_auth_header_name = fields.Char(related='company_id.son_auth_header_name', readonly=False)
    son_basic_username = fields.Char(related='company_id.son_basic_username', readonly=False)
    son_success_path = fields.Char(related='company_id.son_success_path', readonly=False)
    son_success_value = fields.Char(related='company_id.son_success_value', readonly=False)
    son_message_path = fields.Char(related='company_id.son_message_path', readonly=False)
    son_reference_path = fields.Char(related='company_id.son_reference_path', readonly=False)

    regulatory_block_on_failed = fields.Boolean(related='company_id.regulatory_block_on_failed', readonly=False)
    regulatory_block_on_unchecked = fields.Boolean(related='company_id.regulatory_block_on_unchecked', readonly=False)
    regulatory_cache_days = fields.Integer(related='company_id.regulatory_cache_days', readonly=False)
