# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    nafdac_api_endpoint = fields.Char(related='company_id.nafdac_api_endpoint', readonly=False)
    nafdac_api_key = fields.Char(related='company_id.nafdac_api_key', readonly=False)
    nafdac_timeout = fields.Integer(related='company_id.nafdac_timeout', readonly=False)

    son_api_endpoint = fields.Char(related='company_id.son_api_endpoint', readonly=False)
    son_api_key = fields.Char(related='company_id.son_api_key', readonly=False)
    son_timeout = fields.Integer(related='company_id.son_timeout', readonly=False)

    regulatory_block_on_failed = fields.Boolean(related='company_id.regulatory_block_on_failed', readonly=False)
    regulatory_block_on_unchecked = fields.Boolean(related='company_id.regulatory_block_on_unchecked', readonly=False)
    regulatory_cache_days = fields.Integer(related='company_id.regulatory_cache_days', readonly=False)
