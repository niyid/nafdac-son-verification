# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import fields, models


class ProductCategory(models.Model):
    _inherit = 'product.category'

    requires_regulatory_verification = fields.Boolean(
        string='Requires NAFDAC/SON Verification',
        help="Products in this category default to requiring regulatory "
             "verification (e.g. Pharmaceuticals, Food & Beverage, Cosmetics, "
             "Electrical Appliances). Can still be overridden per product.")
    default_regulatory_body = fields.Selection(
        [('none', 'Not Regulated'), ('nafdac', 'NAFDAC'), ('son', 'SON'), ('both', 'NAFDAC & SON')],
        string='Default Regulatory Body', default='none')
