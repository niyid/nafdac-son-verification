# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import _, api, fields, models

from .verification_log import VERIFICATION_STATUS_SELECTION


class StockLot(models.Model):
    _name = 'stock.lot'
    _inherit = ['stock.lot', 'nafdac.son.verification.mixin']

    # Batch-specific overrides. Regulatory numbers are frequently renewed or
    # re-issued per manufacturing batch even though the product/SKU doesn't
    # change, so these take precedence over the product-level values.
    nafdac_reg_number = fields.Char(
        string='NAFDAC Registration No. (Batch)',
        help="Leave empty to fall back to the value set on the Product.")
    son_mancap_number = fields.Char(
        string='SON MANCAP/SONCAP No. (Batch)',
        help="Leave empty to fall back to the value set on the Product.")

    verification_status = fields.Selection(
        VERIFICATION_STATUS_SELECTION, string='Verification Status',
        default='not_checked', copy=False, tracking=True)
    last_verified_date = fields.Datetime(string='Last Checked On', copy=False)
    verification_log_ids = fields.One2many(
        'nafdac.son.verification.log', 'lot_id', string='Verification Logs')
    verification_log_count = fields.Integer(compute='_compute_verification_log_count')

    requires_regulatory_verification = fields.Boolean(
        related='product_id.requires_regulatory_verification', string='Requires Verification')
    regulatory_body = fields.Selection(related='product_id.regulatory_body', string='Regulatory Body')

    def _compute_verification_log_count(self):
        for lot in self:
            lot.verification_log_count = len(lot.verification_log_ids)

    def _effective_reference_number(self, regulatory_body):
        self.ensure_one()
        if regulatory_body == 'nafdac':
            return self.nafdac_reg_number or self.product_id.nafdac_reg_number
        elif regulatory_body == 'son':
            return self.son_mancap_number or self.product_id.son_mancap_number
        return False

    # --- Mixin implementation ----------------------------------------------------
    def _get_verification_targets(self):
        self.ensure_one()
        product = self.product_id
        if not product.requires_regulatory_verification or product.regulatory_body == 'none':
            return []
        bodies = ['nafdac', 'son'] if product.regulatory_body == 'both' else [product.regulatory_body]
        return [(body, self._effective_reference_number(body)) for body in bodies]

    def _get_verification_log_values(self, regulatory_body, reference_number):
        self.ensure_one()
        return {'product_id': self.product_id.id, 'lot_id': self.id}

    def action_view_verification_logs(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Verification Logs'),
            'res_model': 'nafdac.son.verification.log',
            'view_mode': 'list,form',
            'domain': [('lot_id', '=', self.id)],
        }
