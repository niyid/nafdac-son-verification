# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import _, api, fields, models

# Shared selections - imported by product_template.py / stock_lot.py /
# stock_move_line.py so every model agrees on the same values.
REGULATORY_BODY_SELECTION = [
    ('none', 'Not Regulated'),
    ('nafdac', 'NAFDAC'),
    ('son', 'SON'),
    ('both', 'NAFDAC & SON'),
]

VERIFICATION_STATUS_SELECTION = [
    ('not_checked', 'Not Checked'),
    ('pending', 'Pending'),
    ('verified', 'Verified'),
    ('failed', 'Failed'),
    ('expired', 'Expired'),
    ('error', 'Error'),
]


class NafdacSonVerificationLog(models.Model):
    _name = 'nafdac.son.verification.log'
    _description = 'NAFDAC / SON Verification Log'
    _order = 'create_date desc, id desc'
    _rec_name = 'display_name'

    display_name = fields.Char(compute='_compute_display_name', store=True)

    regulatory_body = fields.Selection(
        [('nafdac', 'NAFDAC'), ('son', 'SON')],
        string='Regulatory Body', required=True, index=True)
    reference_number = fields.Char(string='Reference Number Checked', required=True)

    product_id = fields.Many2one('product.product', string='Product', index=True, ondelete='cascade')
    product_tmpl_id = fields.Many2one('product.template', string='Product Template',
                                       related='product_id.product_tmpl_id', store=True, index=True)
    lot_id = fields.Many2one('stock.lot', string='Lot/Serial', index=True, ondelete='cascade')
    picking_id = fields.Many2one('stock.picking', string='Related Transfer', index=True)
    move_line_id = fields.Many2one('stock.move.line', string='Related Move Line')

    result_status = fields.Selection(VERIFICATION_STATUS_SELECTION, string='Result',
                                      required=True, default='pending', index=True)
    message = fields.Text(string='Provider Message')
    raw_response = fields.Text(string='Raw Response')
    external_reference = fields.Char(string='External Reference Returned',
                                      help="Identifier/confirmation code returned by the provider, if any.")

    checked_by = fields.Many2one('res.users', string='Checked By', default=lambda self: self.env.user)
    check_datetime = fields.Datetime(string='Checked On', default=fields.Datetime.now, required=True)
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)

    is_manual = fields.Boolean(string='Manually Triggered', default=True,
                                help="False when triggered automatically by the scheduled re-verification action.")

    @api.depends('regulatory_body', 'reference_number', 'result_status')
    def _compute_display_name(self):
        status_labels = dict(VERIFICATION_STATUS_SELECTION)
        body_labels = dict([('nafdac', 'NAFDAC'), ('son', 'SON')])
        for log in self:
            log.display_name = _(
                "%(body)s check - %(ref)s (%(status)s)",
                body=body_labels.get(log.regulatory_body, log.regulatory_body),
                ref=log.reference_number or _('n/a'),
                status=status_labels.get(log.result_status, log.result_status),
            )
