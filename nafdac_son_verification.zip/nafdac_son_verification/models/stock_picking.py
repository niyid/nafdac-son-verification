# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import _, api, fields, models
from odoo.exceptions import UserError

from .verification_log import VERIFICATION_STATUS_SELECTION


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    has_regulatory_blocker = fields.Boolean(
        string='Has Regulatory Blocker', compute='_compute_regulatory_warning')
    regulatory_warning = fields.Text(
        string='Regulatory Warning', compute='_compute_regulatory_warning',
        help="Non-blocking summary shown on the transfer form so staff can see "
             "and resolve verification issues before attempting to validate.")

    @api.depends('move_line_ids.requires_regulatory_verification',
                 'move_line_ids.regulatory_verification_status',
                 'move_line_ids.lot_id', 'move_line_ids.product_id')
    def _compute_regulatory_warning(self):
        for picking in self:
            company = picking.company_id or self.env.company
            block_failed = company.regulatory_block_on_failed
            block_unchecked = company.regulatory_block_on_unchecked
            offenders = []
            for move_line in picking.move_line_ids:
                if not move_line.requires_regulatory_verification:
                    continue
                status = move_line._get_effective_verification_status()
                is_blocking = (
                    (block_failed and status in ('failed', 'error'))
                    or (block_unchecked and status in ('not_checked', 'pending', 'expired'))
                )
                if is_blocking:
                    identifier = move_line.lot_id.name or move_line.product_id.display_name
                    offenders.append(_(
                        "%(product)s [%(lot)s]: %(status)s",
                        product=move_line.product_id.display_name,
                        lot=identifier,
                        status=status,
                    ))
            picking.has_regulatory_blocker = bool(offenders)
            picking.regulatory_warning = "\n".join(offenders) if offenders else False

    def _pre_action_done_hook(self):
        self._check_regulatory_verification()
        return super()._pre_action_done_hook()

    def _check_regulatory_verification(self):
        """Block validation of transfers containing a regulated product/lot
        whose verification status is not acceptable, per company policy.

        Policy is read from res.company:
          * regulatory_block_on_failed    -> blocks on 'failed' / 'error'
          * regulatory_block_on_unchecked -> also blocks on 'not_checked' /
                                              'pending' / 'expired'
        """
        blocking_offenders = self.env['stock.move.line']
        for picking in self:
            company = picking.company_id or self.env.company
            block_failed = company.regulatory_block_on_failed
            block_unchecked = company.regulatory_block_on_unchecked

            if not (block_failed or block_unchecked):
                continue

            for move_line in picking.move_line_ids:
                if not move_line.requires_regulatory_verification:
                    continue
                status = move_line._get_effective_verification_status()
                is_blocking = (
                    (block_failed and status in ('failed', 'error'))
                    or (block_unchecked and status in ('not_checked', 'pending', 'expired'))
                )
                if is_blocking:
                    blocking_offenders |= move_line

        if blocking_offenders:
            lines = []
            status_labels = dict(VERIFICATION_STATUS_SELECTION)
            for move_line in blocking_offenders:
                status = move_line._get_effective_verification_status()
                status_label = status_labels.get(status, status)
                identifier = move_line.lot_id.name or move_line.product_id.display_name
                lines.append(_(
                    "  - %(product)s [%(lot)s]: %(status)s",
                    product=move_line.product_id.display_name,
                    lot=identifier,
                    status=status_label,
                ))
            raise UserError(_(
                "This transfer cannot be validated: the following regulated "
                "products have not passed NAFDAC/SON verification:\n%(lines)s\n\n"
                "Run 'Verify Now' on the product or lot, or adjust the blocking "
                "policy in Settings > Inventory > Regulatory Verification.",
                lines="\n".join(lines),
            ))
